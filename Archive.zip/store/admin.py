from django.contrib import admin

# Register your models here.
from django.contrib import admin
from store.models import Product,Category,Customer,Order
from import_export.admin import ImportExportModelAdmin
# Register your models here.



class ProductAdmin(ImportExportModelAdmin):
	list_display=['id','name','price','category','description','image']
	###Adding this line so that we Can Search/filter user result in case of any changes or to Check last time when he updated#######
	search_fields = ('name','image','price')
admin.site.register(Product,ProductAdmin)


class CategoryAdmin(ImportExportModelAdmin):
	list_display=['id','name']
	###Adding this line so that we Can Search/filter user result in case of any changes or to Check last time when he updated#######
	search_fields = ('name',)
admin.site.register(Category,CategoryAdmin)

class CustomerAdmin(ImportExportModelAdmin):
	list_display=['first_name','last_name','email','phone','password']
	###Adding this line so that we Can Search/filter user result in case of any changes or to Check last time when he updated#######
	search_fields = ('name',)
admin.site.register(Customer,CustomerAdmin)


class OrderAdmin(ImportExportModelAdmin):
	list_display=['customer','product','quantity','price','date','address','phone','status']
	###Adding this line so that we Can Search/filter user result in case of any changes or to Check last time when he updated#######
	search_fields = ('customer','product','price','date','status')
admin.site.register(Order,OrderAdmin)