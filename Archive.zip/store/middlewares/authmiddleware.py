from django.http import HttpResponse
from django.shortcuts import redirect

def authmiddleware1(get_response):
	# one time configuration and initialization..

	def middleware(request):
		print('Customer hai ki nhi: ',request.session.get('login_customerID'))
		print('#####  Middleware Order in Action..Checking details ######:)')
		###now saving details of path and where we need to redirect from where left.
		returnurl12 = request.META['PATH_INFO']
		print('Path Information :',request.META['PATH_INFO'])
		if request.session.get('login_customerID'):
			pass
		else:
			return redirect(f'login?return_urlsh={returnurl12}')

		response = get_response(request)
		return response

	return middleware


#now we need to define things in login views also.