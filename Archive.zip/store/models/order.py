from django.db import models
from .product import Product ##We'll make product as a Foreign Key.
from .customer import Customer
import datetime
# Create your models here.

class Order(models.Model):
	product = models.ForeignKey(Product, on_delete=models.CASCADE)
	customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
	quantity = models.IntegerField(default=1)
	price = models.IntegerField()
	date = models.DateField(default=datetime.datetime.today)
	address = models.CharField(max_length=50, default="" )
	phone = models.CharField(max_length=12, default='')
	status = models.BooleanField(default=False)
	# STATUS_CHOICES = (('draft','Pending'),('published','Completed'))



	def __str__(self):
		return str(self.product)

class Meta:
	ordering=('-date',)