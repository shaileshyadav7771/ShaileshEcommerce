from django import template
###Here we are writing logic for Cart Filteration in //index.html
register = template.Library()


@register.filter(name='is_in_cart')
def is_in_cart(product,cart):
	keys=cart.keys()
	for id in keys:
		if int(id) == product.id:
			print(type(id), type(product.id))
			return True
	return False

###For Count here we will Create Another Filter

@register.filter(name='cart_value')
def cart_value(product,cart):
	keys=cart.keys()
	for id in keys:
		if int(id) == product.id:
			print('cart Value & Product ID:',type(id), type(product.id))
			return cart.get(id)
	return 0

@register.filter(name='price_total')
def price_total(product,cart):
	return product.price * cart_value(product,cart)


@register.filter(name='total_cart_price')
def total_cart_price(prdouctidinside, cart):
	sum=0
	for singleitem in prdouctidinside:#here from cart.html passing all product list
		sum += price_total(singleitem,cart)
	return sum

