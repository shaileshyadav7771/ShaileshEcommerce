from django import template
###Here we are writing logic for Cart Filteration in //index.html
register = template.Library()


@register.filter(name='currancy')
def currency(number):
	return "₹ "+str(number)


#####Creating filter for orders.html view ###########

@register.filter(name='multiply')
def multiply(number1,number2):
	return number1 * number2