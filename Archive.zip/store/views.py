from django.shortcuts import render, redirect ,HttpResponseRedirect
from django.http import HttpResponse
from .models.product import Product
from .models.customer import Customer
from .models.category import Category
from .models.order import Order
from django.contrib.auth.hashers import make_password, check_password
# Create your views here.
from django.views import View


# print(make_password('1234'))
# print(check_password('1234','pbkdf2_sha256$180000$gj9Y5muPZKgx$YdcCE+Wvz0AIBwXSa4yNW0piDPJzfJVx46K4uqBCc1c='))
###In terminal we Can see it is reverting True as has password is of 1234 only.
class Index(View):
	def get(self,request):
		##Creating An Empty Card...
		cart = request.session.get('cart')
		if not cart:
			request.session['cart'] = {}
		allproduct = None
		# here I'm Clearing session stored cart datawhen we'll serve home page.
		# request.session.clear()#here problem is we have Cleared session so will not get ID email ID instead of this we'll get None.
		# request.session.get('cart').clear()
		allcategorie = Category.objects.all();
		categoryID = request.GET.get('category')
		print('Category ID is : ',categoryID)
		if categoryID:
			allproduct = Product.objects.filter(category=categoryID)
		else:
			allproduct = Product.objects.all();
		data = {}
		data['allproducts'] = allproduct
		data['allcategorie'] = allcategorie
		# print('All Products and All Categorie:',allproduct,allcategorie)
		print('Your Unique ID is:',
		request.session.get('login_customerID'))  ##Taking from login stored session with key name
		print('Your session Email ID is:', request.session.get('login_customereEMAIL'))

		return render(request, 'index.html', data)

	def post(self,request):
		product=request.POST.get('product')
		print('Request when user click on add to Card/product ID:',product)
		cart=request.session.get('cart')
		print('Card items when user click on add to Card:',cart)
		#Now logic to minus/decrease Count.
		minus_card=request.POST.get('minus_to_card')

		if cart:
			value=cart.get(product)
			if value:
				if minus_card:
					if value <=1:
						cart.pop(product)
						print('Value pop')
					else:
						cart[product] = value-1
						print('product is -1 ')
				else:
					cart[product] = value+1
			else:
				cart[product] = 1
		else:
			cart ={}
			cart[product] = 1
		request.session['cart']=cart
		print('Ordering Items saved in Cart:',request.session['cart'])
		print('product ordering id: ',product)
		return redirect('home')


	
###for validation simplyfig code
###### Creating Views for Signup form #######

class Signup(View):
	def get(self, request):
		return render(request, 'signup.html')

	def post(self, request):
		postdata = request.POST
		first_name = postdata.get('firstname')
		last_name = postdata.get('lastname')
		phone = postdata.get('PhoneNumber')
		email = postdata.get('email')
		password = postdata.get('Password')

		# Now to store filled data if any error is coming so that User not required to fill it again.####
		value = {
			'first_name': first_name,
			'last_name': last_name,
			'phone': phone,
			'email': email,
			# password not passing :) user need to fill it hahhahaa
		}

		####Validating above field at server level####
		error = None
		customer = Customer(first_name=first_name,
		                    last_name=last_name,
		                    phone=phone,
		                    email=email,
		                    password=password)
		if not first_name:
			error = 'First name is required!!'
		elif len(first_name) < 4:
			error = 'First Name must be 4 char length'

		elif not last_name:
			error = 'Last Name is required!.'
		elif len(last_name) < 4:
			error = 'Last Name Must be 4 Character long.'

		elif len(phone) < 10:
			error = 'Mobile number should be of 10 digit.'

		elif Customer.objects.filter(phone=phone):
			error = "Mobile no is already registered."

		elif len(password) < 5:
			error = "Password must be 5 Char length."

		elif len(email) < 6:
			error = "Email Id must be more than 6 Character !"

		elif Customer.objects.filter(email=email):
			error = "Sorry You already have account with this Email ID."

		if not error:
			print(first_name, last_name, email, password, phone)
			customer.password = make_password(customer.password)

			customer.save()
			# best way is to go into urls.py and define name=hompage because tommorow if we'll upload on production this domain will change.
			return redirect('home')
		# return redirect('http://127.0.0.1:8000')this is not recommonded
		# return render(request,'index.html')#paasing data otherwise product will not shown to us after redirecting to index.
		# in this we will not get all product image so we need to check how we can use above data already written code

		else:
			data = {
				'error': error,
				'values': value,
			}
			return render(request, 'signup.html', data)


class Login(View):
	returnurl12 = None # from middleware
	def get(self, request):  # overriding the get method.
		Login.returnurl12 = request.GET.get('returnurl12') #here we'll get return urls and hold it in returnurl12.
		return render(request, 'login.html')

	def post(self, request):
		email = request.POST.get('email')
		password = request.POST.get('password')
		print('User Entered Password and Email ID is:',password, email)
		# Now we will try to match user entered email ID and search it in db(here we Can't use pass because it is in ecrypted mode we can see from admin panel
		# to filter result we can use Customer.objects.filter which will return match in list form but we want a single object so better is to use
		# Customer.objects.get(email=email))
		# drawback of get is that if result is matched then good else it will give error.so better is to use
		try:
			login_customer = Customer.objects.get(email=email)
			error = None
			if login_customer:
				print('---just logined Customer Email ID----',email)
				print('+++Checking User Password in Db ++')
				flag = check_password(password, login_customer.password)
				print('Password Matches in Login entering User:',flag)
				# if user email ID is exit then we'll Check his password.:)
				if flag:
					print('Return URL HAU ki nay:', Login.returnurl12)
					request.session['login_customerID'] = login_customer.id #this we have used in base.html if customer login then he can see buttons
					#Now in base.html we will Check if user is logined or not..
					request.session['login_customereEMAIL'] = login_customer.email
					request.session['login_customerefirst_name'] = login_customer.first_name


					############Here we will apply condition Middleware to check if we need to redirect or not
					if Login.returnurl12:
						print('Return URL Mila ki Nhi bhai:',Login.returnurl12)
						#import HttpResponseRedirect
						return HttpResponseRedirect(Login.returnurl12)
					else:
						#if Login.returnurl12: not exits then we will redirect to home but before that we'll assign None.
						print('Return URL nhi mil rha hai Bhai')
						Login.returnurl12 = None
						return redirect('home')
					
				else:
					error = 'Entered Email ID OR Password is Incorrect'
					return render(request, 'login.html', {'error': error})

		except:
			error = 'Entered Email ID OR Password is Incorrect'
		return render(request, 'login.html', {'error': error})
def logout(request):
	request.session.clear()
	return redirect('login')


##For Card ###############

class Cart(View):
	def get(self, request,):
		#Now we will take product details and also convert it into list form.
		ids=list(request.session.get('cart').keys())
		# print('Total Items added into Card',list(request.session.get('cart').keys()))
		prdouctidinside =Product.objects.filter(id__in = ids)
		print('Cart containg IDS:',prdouctidinside)
		return render(request, 'cart.html',{'prdouctidinside' : prdouctidinside})


#######Creating class for check_out#########
class Check_out(View):
	def post(self,request):
		# print(request.POST)
		address =request.POST.get('address')
		phone =request.POST.get('phone')
		#remaining things we will take it from Customer
		customer = request.session.get('login_customerID')#from session
		print('Checkout stage:add/phone/customerID',address,phone,customer)
		#inside cart we have saved product as key.
		cart = request.session.get('cart')
		#now we will take all products out
		productidinlistform = list(cart.keys())  #converted into list form.
		#now we'll get all product by passing this id..
		products = Product.objects.filter(id__in=productidinlistform)
		print('Showing Cart Quantity:',cart)
		print('All Retrieved ID in Checkout steps froms session:',products)


		##now let's Create order object ###########
		for product in products:
			order= Order(
				          customer = Customer(id = customer),
			              product = product,
						  price = product.price,
						  address = address,
						  phone = phone,
						  quantity = cart.get(str(product.id)) ##very imp withou str it'll give error
			)
			order.save()

		#Now once order is placed and saved to dbwe need to empty the card.
		request.session['cart'] = {}
		
		return redirect('home')


###########Now we will handle orders.html get request############
# from store.middlewares.authmiddleware import authmiddleware1
#We can not use our decorator we need to import method_decoratoe and inside it we will pass our decorator.
# from django.utils.decorators import method_decorator
class Orders(View):
	# @method_decorator(authmiddleware1)
	#instead of above way we will apply it in urls.py becz what we we have more no of method we can not define decorator for everything.
	#Now we don't want to run middle ware for all application so what we will do here we will import and use 
	def get(self,request):
		#now we want to show customer order so first take his details from session.
		logincustomer = request.session.get('login_customerID')
		get_order_by_cutomer = Order.objects.filter(customer =logincustomer ).order_by('-date')
		#here in Orders model we user customer foreign key so'll use same.
		print('Order by login Customer:', get_order_by_cutomer  )
		return render(request,'orders.html',{'get_order_by_cutomer' : get_order_by_cutomer})
























































































		

# from django.shortcuts import render, redirect
# from django.http import HttpResponse
# from .models.product import Product
# from .models.customer import Customer
# from .models.category import Category
# from django.contrib.auth.hashers import make_password,check_password
# # Create your views here.
# from django.views.generic import View

# # print(make_password('1234'))
# # print(check_password('1234','pbkdf2_sha256$180000$gj9Y5muPZKgx$YdcCE+Wvz0AIBwXSa4yNW0piDPJzfJVx46K4uqBCc1c='))
# ###In terminal we Can see it is reverting True as has password is of 1234 only.
# def index(request):
# 	allproduct = None
# 	allcategorie = Category.objects.all();
# 	categoryID = request.GET.get('category')
# 	print(categoryID)
# 	if categoryID:
# 		allproduct = Product.objects.filter(category=categoryID)
# 	else:
# 		allproduct = Product.objects.all();
# 	data={}
# 	data['allproducts']=allproduct
# 	data['allcategorie']=allcategorie

# 	return render(request,'index.html', data)

# ###for validation simplyfig code

# ###### Creating Views for Signup form #######
# def signup(request):
# 	if request.method == 'GET':
# 			print(request.method)
# 			return render(request,'signup.html')
# 	else:
# 		postdata=request.POST
# 		first_name = postdata.get('firstname')
# 		last_name = postdata.get('lastname')
# 		phone = postdata.get('PhoneNumber')
# 		email = postdata.get('email')
# 		password = postdata.get('Password')

# 		#Now to store filled data if any error is coming so that User not required to fill it again.####
# 		value={
# 			'first_name' : first_name,
# 			'last_name' : last_name,
# 			'phone' : phone,
# 			'email' : email,
# 			#password not passing :) user need to fill it hahhahaa
# 		}


# 		####Validating above field at server level####
# 		error = None
# 		customer = Customer(first_name=first_name,
# 		                    last_name=last_name,
# 							phone=phone,
# 							email=email,
# 							password=password)
# 		if not first_name:
# 			error = 'First name is required!!'
# 		elif len(first_name) < 4:
# 			error = 'First Name must be 4 char length'

# 		elif not last_name:
# 			error ='Last Name is required!.'
# 		elif len(last_name) < 4:
# 			error = 'Last Name Must be 4 Character long.'

# 		elif len(phone) < 10:
# 			error ='Mobile number should be of 10 digit.'

# 		elif Customer.objects.filter(phone=phone):
# 			error = "Mobile no is already registered."

# 		elif len(password) < 5:
# 			error ="Password must be 5 Char length."

# 		elif len(email) <6:
# 			error = "Email Id must be more than 6 Character !"

# 		elif Customer.objects.filter(email=email):
# 			error = "Sorry You already have account with this Email ID."


# 		if not error:
# 			print(first_name,last_name,email,password,phone)
# 			customer.password = make_password(customer.password)

# 			customer.save()
# 			#best way is to go into urls.py and define name=hompage because tommorow if we'll upload on production this domain will change.
# 			return redirect('home')
# 			# return redirect('http://127.0.0.1:8000')this is not recommonded
# 			# return render(request,'index.html')#paasing data otherwise product will not shown to us after redirecting to index.
# 			# in this we will not get all product image so we need to check how we can use above data already written code

# 		else:
# 			data = {
# 				'error': error,
# 				'values': value,
# 			}
# 			return render(request,'signup.html', data)

# def login(request):
# 	if request.method == 'GET':
# 		return render (request, 'login.html')
# 	else:
# 		email = request.POST.get('email')
# 		password = request.POST.get('password')
# 		print(password,email)
# 		#Now we will try to match user entered email ID and search it in db(here we Can't use pass because it is in ecrypted mode we can see from admin panel
# 		# to filter result we can use Customer.objects.filter which will return match in list form but we want a single object so better is to use
# 		# Customer.objects.get(email=email))
# 		#drawback of get is that if result is matched then good else it will give error.so better is to use
# 		try:
# 			login_customer = Customer.objects.get(email=email)
# 			error = None
# 			if login_customer:
# 				print('---just logined Customer Email ID----')
# 				print(email)
# 				print('+++Checking User Password in Db ++')
# 				flag = check_password(password, login_customer.password)
# 				print(flag)
# 				# if user email ID is exit then we'll Check his password.:)
# 				if flag:
# 					return redirect('home')
# 				else:
# 					error = 'Entered Email ID OR Password is Incorrect'
# 					return render(request, 'login.html', {'error': error})

# 		except:
# 			error = 'Entered Email ID OR Password is Incorrect'		
# 		return render(request, 'login.html', {'error': error})
